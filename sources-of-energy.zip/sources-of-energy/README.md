# sources-of-energy

A web project for Earth Science, Empowerment Technologies, and General Mathematics showcasing facts and misconceptions about energy through science and logic.

## Team
- Harder, Joe Rychel (leader)
- Folgar, Ariana
- Manalo, Nikol
- Manejar, Jameela
- Maquiran, Jude Angelo
- Moreno, Khrizzia Joy
- Samino, Rheanna Quenneth

## Tech stack
- Java 17+
- Spring Boot 3.x
- Thymeleaf
- Maven

## Run locally
1. Install Java 17+ and Maven.
2. From project root:
```bash
mvn clean package
mvn spring-boot:run
```
3. Open `http://localhost:8080` in your browser.

## Project structure
- `pom.xml` - Maven configuration
- `src/main/java` - Java source files
- `src/main/resources/templates` - Thymeleaf templates (HTML)
- `src/main/resources/static` - CSS and JS assets

## Notes
- The Reflection, Sources, and Video pages are placeholders. Replace the iframe `VIDEO_ID` in `video.html` with a real YouTube video ID if needed.
- Feel free to edit templates and CSS to customize the look.

## Credits
Created for classroom use by the team listed above.
