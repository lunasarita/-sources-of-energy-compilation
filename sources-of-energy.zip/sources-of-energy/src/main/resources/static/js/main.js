document.addEventListener('DOMContentLoaded', function(){
  const h2 = document.querySelector('main h2');
  if(h2) { h2.setAttribute('tabindex','-1'); h2.focus(); }
});
