package com.example.energy.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.*;

@Controller
public class SiteController {

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("title", "Sources of Energy Facts and Misconceptions");
        model.addAttribute("subtitle", "A Science & Logic Compilation");
        return "index";
    }

    @GetMapping("/team")
    public String team(Model model) {
        List<String> members = Arrays.asList(
                "Harder, Joe Rychel (leader)",
                "Folgar, Ariana",
                "Manalo, Nikol",
                "Manejar, Jameela",
                "Maquiran, Jude Angelo",
                "Moreno, Khrizzia Joy",
                "Samino, Rheanna Quenneth"
        );
        model.addAttribute("members", members);
        return "team";
    }

    @GetMapping("/entries")
    public String entries(Model model) {
        List<Map<String,String>> entries = new ArrayList<>();

        Map<String,String> e1 = new HashMap<>();
        e1.put("title", "“Solar panels become completely useless when it’s cloudy.”");
        e1.put("proposition", "If the sky is cloudy, then solar panels produce no electricity. (C → E)");
        e1.put("truth", "False – Solar panels will still work, no matter the weather condition.");
        e1.put("explanation", "Even when skies seem to be completely covered in clouds, some sunlight can still reach the Earth by scattering (diffuse solar radiation). Solar panels can convert this sunlight into electricity, though not as powerful as under full sun. In fact, solar panels don’t depend only on direct sunlight. According to the U.S. Department of Energy, some sunlight still reaches the earth.");
        e1.put("author", "Harder");
        entries.add(e1);

        Map<String,String> e2 = new HashMap<>();
        e2.put("title", "“Solar energy is the cleanest energy source because it has zero environmental impact.”");
        e2.put("proposition", "S = Solar energy is used; Z = Zero environmental impact; Symbolized: S & Z");
        e2.put("truth", "False – The statement is false because while solar power is significantly cleaner than fossil fuels, saying it has “zero environmental impact” is an exaggeration.");
        e2.put("explanation", "Solar technologies do not produce air pollution or greenhouse gases during operation. However, producing and deploying solar panels and infrastructure can have environmental effects (manufacturing, land use, resource extraction, end-of-life disposal). Using solar often reduces larger environmental impacts by replacing fossil fuels.");
        e2.put("author", "Folgar");
        entries.add(e2);

        Map<String,String> e3 = new HashMap<>();
        e3.put("title", "“Wind turbines can operate efficiently in any location.”");
        e3.put("proposition", "If a location has wind turbines, then they operate efficiently. (P → Q)");
        e3.put("truth", "False – Wind efficiency depends on wind speed and consistency.");
        e3.put("explanation", "Wind turbines require consistent wind speeds (typically above ~6 m/s) to be productive. Coastal areas, plains, and high-altitude sites are ideal. In low-wind zones turbines may underperform, so site selection is critical.");
        e3.put("author", "Manejar");
        entries.add(e3);

        Map<String,String> e4 = new HashMap<>();
        e4.put("title", "“Solar panels generate electricity when exposed to sunlight.”");
        e4.put("proposition", "If sunlight strikes a solar panel (S), then electricity is generated (E). (S → E)");
        e4.put("truth", "True – Solar panels reliably produce electricity when sunlight reaches their surface (output varies with intensity/conditions).");
        e4.put("explanation", "Photons from sunlight are absorbed by PV cells and converted to electricity via the photovoltaic effect. Output depends on sunlight intensity, orientation, panel efficiency, and weather.");
        e4.put("author", "Manalo");
        entries.add(e4);

        Map<String,String> e5 = new HashMap<>();
        e5.put("title", "“Solar energy is a renewable and sustainable energy source.”");
        e5.put("proposition", "If energy comes from the sun, then it is renewable and sustainable. (P → Q)");
        e5.put("truth", "True – The sun provides an effectively inexhaustible energy supply over human time scales.");
        e5.put("explanation", "Solar energy is renewable because sunlight is continuously available for billions of years; it is sustainable in that it emits no greenhouse gases during operation and does not deplete resources like fossil fuels.");
        e5.put("author", "Moreno");
        entries.add(e5);

        model.addAttribute("entries", entries);
        return "entries";
    }

    @GetMapping("/reflection")
    public String reflection(Model model) {
        // placeholder: reflection content can be added later via templates
        return "reflection";
    }

    @GetMapping("/sources")
    public String sources() {
        return "sources";
    }

    @GetMapping("/video")
    public String video() {
        return "video";
    }
}
