package com.example.energy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SourcesOfEnergyApplication {
    public static void main(String[] args) {
        SpringApplication.run(SourcesOfEnergyApplication.class, args);
    }
}
